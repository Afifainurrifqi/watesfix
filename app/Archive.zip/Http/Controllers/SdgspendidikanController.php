<?php

namespace App\Http\Controllers;

use App\Models\agama;
use App\Models\pendidikan;
use App\Models\pekerjaan;
use App\Models\status;
use App\Models\goldar;
use App\Models\datapenduduk;
use App\Models\sdgspendidikan;
use App\Http\Requests\StoresdgspendidikanRequest;
use App\Http\Requests\UpdatesdgspendidikanRequest;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;

class SdgspendidikanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        $totalPenduduk = datapenduduk::count();
        $dataTerisi = sdgspendidikan::count();
        $presentase = $totalPenduduk > 0 ? ($dataTerisi / $totalPenduduk) * 100 : 0;

        // Standarisasi hanya ambil nilai yang sesuai dropdown
        $validPendidikan = [
            'Tidak sekolah',
            'SD dan sederajat',
            'SMP dan sederajat',
            'SMA dan sederajat',
            'DIPLOMA I - III',
            'S-1 dan sederajat',
            'S-2 dan sederajat',
            'S-3 dan sederajat',
            'Pesantren, Seminari, Wihara, dan sejenisnya',
            'Lainnya'
        ];

        $pendidikanGroup = sdgspendidikan::whereIn('pendidikan_tertinggi', $validPendidikan)
            ->get()
            ->countBy('pendidikan_tertinggi')
            ->sortByDesc(fn($count) => $count); // urutkan dari terbanyak

        $pendidikanLabels = $pendidikanGroup->keys()->toArray();
        $pendidikanCounts = $pendidikanGroup->values()->toArray();

        return view('sdgs.individu.datasdgspendidikan', compact(
            'presentase',
            'pendidikanLabels',
            'pendidikanCounts'
        ));


    }


    public function admin_index(Request $request)
    {
        $totalPenduduk = datapenduduk::count();
        $dataTerisi = sdgspendidikan::count();
        $presentase = $totalPenduduk > 0 ? ($dataTerisi / $totalPenduduk) * 100 : 0;

        // Standarisasi hanya ambil nilai yang sesuai dropdown
        $validPendidikan = [
            'Tidak sekolah',
            'SD dan sederajat',
            'SMP dan sederajat',
            'SMA dan sederajat',
            'DIPLOMA I - III',
            'S-1 dan sederajat',
            'S-2 dan sederajat',
            'S-3 dan sederajat',
            'Pesantren, Seminari, Wihara, dan sejenisnya',
            'Lainnya'
        ];

        $pendidikanGroup = sdgspendidikan::whereIn('pendidikan_tertinggi', $validPendidikan)
            ->get()
            ->countBy('pendidikan_tertinggi')
            ->sortByDesc(fn($count) => $count); // urutkan dari terbanyak

        $pendidikanLabels = $pendidikanGroup->keys()->toArray();
        $pendidikanCounts = $pendidikanGroup->values()->toArray();

        return view('sdgs.individu.admin_data_sdgs_pendidikan', compact(
            'presentase',
            'pendidikanLabels',
            'pendidikanCounts'
        ));
    }

    public function jsonadmin(Request $request)
    {
        $allowedDatakValues = ['tetap', 'tidaktetap'];

        $query = Datapenduduk::with(['kk', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status', 'detailkk.kk'])
            ->whereIn('Datak', $allowedDatakValues);

        return DataTables::of($query)

            ->addColumn('nokk', function ($row) {
                return optional($row->detailkk->kk)->nokk;
            })
            // ⬇️ Izinkan pencarian global di kolom NO KK (relasi)
            ->filterColumn('nokk', function ($q, $keyword) {
                $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                    $qq->where('nokk', 'like', "%{$keyword}%");
                });
            })
            // (opsional) izinkan sorting kolom NO KK
            ->orderColumn('nokk', function ($q, $order) {
                $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
                    ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
                    ->orderBy('kks.nokk', $order)
                    ->select('datapenduduks.*'); // hindari duplikasi kolom
            })
            ->addColumn('action', function ($row) {
                return '<td>
                            <a href="' . route('pendidikan.show', ['show' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Lihat Data">
                                <i class="fas fa-book"></i>
                            </a>
                            <a href="' . route('pendidikan.edit', ['nik' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>';
            })
            ->addColumn('pendidikan_tertinggi', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pendidikan_tertinggi : '';

                return $kondisi;
            })
            ->addColumn('berapa_tahunp', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->berapa_tahunp : '';

                return $kondisi;
            })
            ->addColumn('pendidikan_diikuti', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pendidikan_diikuti : '';

                return $kondisi;
            })
            ->addColumn('bahasa_Rumah', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bahasa_Rumah : '';

                return $kondisi;
            })
            ->addColumn('bahasa_Formal', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bahasa_Formal : '';

                return $kondisi;
            })
            ->addColumn('jumlah_kerja1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->jumlah_kerja1 : '';

                return $kondisi;
            })
            ->addColumn('skamling1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->skamling1 : '';

                return $kondisi;
            })
            ->addColumn('pesta_rakyat1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pesta_rakyat1 : '';

                return $kondisi;
            })
            ->addColumn('frekuensiml', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->frekuensiml : '';

                return $kondisi;
            })
            ->addColumn('frekuensib', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->frekuensib : '';

                return $kondisi;
            })
            ->addColumn('frekuensimn', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->frekuensimn : '';

                return $kondisi;
            })
            ->addColumn('mendapatp1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->mendapatp1 : '';

                return $kondisi;
            })
            ->addColumn('bagaiamanap', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bagaiamanap : '';

                return $kondisi;
            })
            ->addColumn('pernahmasukan', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pernahmasukan : '';

                return $kondisi;
            })
            ->addColumn('keterbukaands', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->keterbukaands : '';

                return $kondisi;
            })
            ->addColumn('bencana1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bencana1 : '';

                return $kondisi;
            })
            ->addColumn('apakahb', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->apakahb : '';

                return $kondisi;
            })
            ->addColumn('apakahd', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->apakahd : '';

                return $kondisi;
            })
            ->addColumn('apakahp', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->apakahp : '';

                return $kondisi;
            })


            ->rawColumns([
                'action',
                'pendidikan_tertinggi',
                'berapa_tahunp',
                'pendidikan_diikuti',
                'bahasa_Rumah',
                'bahasa_Formal',
                'jumlah_kerja1',
                'skamling1',
                'pesta_rakyat1',
                'frekuensiml',
                'frekuensib',
                'frekuensimn',
                'mendapatp1',
                'bagaiamanap',
                'pernahmasukan',
                'keterbukaands',
                'bencana1',
                'apakahb',
                'apakahd',
                'apakahp',
            ])
            ->toJson();
    }


    public function json(Request $request)
    {
        $allowedDatakValues = ['tetap', 'tidaktetap'];

        // Cek apakah ada pencarian global dari DataTables atau filter nokk khusus
        $hasGlobalSearch = filled(data_get($request->all(), 'search.value')); // DataTables global search
        $hasNokkFilter   = $request->filled('nokk');

        if (! $hasGlobalSearch && ! $hasNokkFilter) {
            // Tidak ada search & tidak ada filter spesifik → sembunyikan data
            $query = Datapenduduk::query()->whereRaw('1=0');
        } else {
            // Ada search atau ada filter nokk → tampilkan data dengan relasi
            $query = Datapenduduk::with([
                'kk',
                'agama',
                'pendidikan',
                'pekerjaan',
                'goldar',
                'status',
                'detailkk.kk',
                'updatedByUser'
            ])->whereIn('Datak', $allowedDatakValues);

            // Filter opsional by NoKK dari parameter khusus
            if ($hasNokkFilter) {
                $nokk = $request->input('nokk');
                $query->whereHas('detailkk.kk', function ($qq) use ($nokk) {
                    $qq->where('nokk', 'like', "%{$nokk}%");
                });
            }
            // Catatan: global search akan ditangani otomatis oleh Yajra pada kolom sederhana.
            // Untuk kolom relasi (nokk) kita sediakan filterColumn di bawah.
        }
        return DataTables::of($query)

            ->addColumn('nokk', function ($row) {
                return optional($row->detailkk->kk)->nokk;
            })
            // ⬇️ Izinkan pencarian global di kolom NO KK (relasi)
            ->filterColumn('nokk', function ($q, $keyword) {
                $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                    $qq->where('nokk', 'like', "%{$keyword}%");
                });
            })
            // (opsional) izinkan sorting kolom NO KK
            ->orderColumn('nokk', function ($q, $order) {
                $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
                    ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
                    ->orderBy('kks.nokk', $order)
                    ->select('datapenduduks.*'); // hindari duplikasi kolom
            })
            ->addColumn('action', function ($row) {
                return '<td>
                            <a href="' . route('pendidikan.show', ['show' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Lihat Data">
                                <i class="fas fa-book"></i>
                            </a>
                            <a href="' . route('pendidikan.edit', ['nik' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>';
            })
            ->addColumn('pendidikan_tertinggi', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pendidikan_tertinggi : '';

                return $kondisi;
            })
            ->addColumn('berapa_tahunp', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->berapa_tahunp : '';

                return $kondisi;
            })
            ->addColumn('pendidikan_diikuti', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pendidikan_diikuti : '';

                return $kondisi;
            })
            ->addColumn('bahasa_Rumah', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bahasa_Rumah : '';

                return $kondisi;
            })
            ->addColumn('bahasa_Formal', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bahasa_Formal : '';

                return $kondisi;
            })
            ->addColumn('jumlah_kerja1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->jumlah_kerja1 : '';

                return $kondisi;
            })
            ->addColumn('skamling1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->skamling1 : '';

                return $kondisi;
            })
            ->addColumn('pesta_rakyat1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pesta_rakyat1 : '';

                return $kondisi;
            })
            ->addColumn('frekuensiml', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->frekuensiml : '';

                return $kondisi;
            })
            ->addColumn('frekuensib', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->frekuensib : '';

                return $kondisi;
            })
            ->addColumn('frekuensimn', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->frekuensimn : '';

                return $kondisi;
            })
            ->addColumn('mendapatp1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->mendapatp1 : '';

                return $kondisi;
            })
            ->addColumn('bagaiamanap', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bagaiamanap : '';

                return $kondisi;
            })
            ->addColumn('pernahmasukan', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->pernahmasukan : '';

                return $kondisi;
            })
            ->addColumn('keterbukaands', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->keterbukaands : '';

                return $kondisi;
            })
            ->addColumn('bencana1', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->bencana1 : '';

                return $kondisi;
            })
            ->addColumn('apakahb', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->apakahb : '';

                return $kondisi;
            })
            ->addColumn('apakahd', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->apakahd : '';

                return $kondisi;
            })
            ->addColumn('apakahp', function ($row) {
                $datapekerjaan = sdgspendidikan::where('nik', $row->nik)->first();
                $kondisi = $datapekerjaan ? $datapekerjaan->apakahp : '';

                return $kondisi;
            })


            ->rawColumns([
                'action',
                'pendidikan_tertinggi',
                'berapa_tahunp',
                'pendidikan_diikuti',
                'bahasa_Rumah',
                'bahasa_Formal',
                'jumlah_kerja1',
                'skamling1',
                'pesta_rakyat1',
                'frekuensiml',
                'frekuensib',
                'frekuensimn',
                'mendapatp1',
                'bagaiamanap',
                'pernahmasukan',
                'keterbukaands',
                'bencana1',
                'apakahb',
                'apakahd',
                'apakahp',
            ])
            ->toJson();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($nik)
    {
        $datap = datapenduduk::where('nik', $nik)->first();
        $datasdgspendidikan = sdgspendidikan::where('nik', $nik)->first();
        $agama = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan = Pekerjaan::all();
        $goldar = Goldar::all();
        $status = Status::all();
        return view('sdgs.individu.editsdgspendidikan', compact('datap', 'datasdgspendidikan', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoresdgspendidikanRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoresdgspendidikanRequest $request)
    {
        $datasdgspendidikan = sdgspendidikan::where('nik', $request->valNIK)->first();
        if ($datasdgspendidikan == NULL) {
            $datasdgspendidikan = new sdgspendidikan();
        }
        $datasdgspendidikan->nik = $request->valNIK;
        $datasdgspendidikan->pendidikan_tertinggi = $request->valpendidikan_tertinggi;
        $datasdgspendidikan->berapa_tahunp = $request->valberapa_tahunp;
        $datasdgspendidikan->pendidikan_diikuti = $request->valpendidikan_diikuti;
        $datasdgspendidikan->bahasa_Rumah = $request->valbahasa_Rumah;
        $datasdgspendidikan->bahasa_Formal = $request->valbahasa_Formal;
        $datasdgspendidikan->jumlah_kerja1 = $request->valjumlah_kerja1;
        $datasdgspendidikan->skamling1 = $request->valskamling;
        $datasdgspendidikan->pesta_rakyat1 = $request->valpesta_rakyat1;
        $datasdgspendidikan->frekuensiml = $request->valfrekuensiml;
        $datasdgspendidikan->frekuensib = $request->valfrekuensib;
        $datasdgspendidikan->frekuensimn = $request->valfrekuensmn;
        $datasdgspendidikan->mendapatp1 = $request->valmendapatp1;
        $datasdgspendidikan->bagaiamanap = $request->valbagaiamanap;
        $datasdgspendidikan->pernahmasukan = $request->valpernahmasukan;
        $datasdgspendidikan->keterbukaands = $request->valketerbukaands;
        $datasdgspendidikan->bencana1 = $request->valbencana1;
        $datasdgspendidikan->apakahb = $request->valapakahb;
        $datasdgspendidikan->apakahd = $request->valapakahd;
        $datasdgspendidikan->apakahp = $request->valapakahp;

        $datasdgspendidikan->save();

        if (auth()->check() && auth()->user()->role === 'admin') {
            return redirect()
                ->route('pendidikan.admin_index')
                ->with('msg', 'Berhasil ditambahkan (Admin)');
        }

        // Default untuk user biasa
        return redirect()
            ->route('pendidikan.index')
            ->with('msg', 'Penduduk Berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\sdgspendidikan  $sdgspendidikan
     * @return \Illuminate\Http\Response
     */
    public function show(sdgspendidikan $sdgspendidikan, $nik)
    {
        $datap = datapenduduk::where('nik', $nik)->first();
        $datasdgspendidikan = sdgspendidikan::where('nik', $nik)->first();
        $agama = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan = Pekerjaan::all();
        $goldar = Goldar::all();
        $status = Status::all();

        return view('sdgs.individu.viewsdgspendidikan', compact('datap', 'datasdgspendidikan', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\sdgspendidikan  $sdgspendidikan
     * @return \Illuminate\Http\Response
     */
    public function edit(sdgspendidikan $sdgspendidikan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatesdgspendidikanRequest  $request
     * @param  \App\Models\sdgspendidikan  $sdgspendidikan
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatesdgspendidikanRequest $request, sdgspendidikan $sdgspendidikan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\sdgspendidikan  $sdgspendidikan
     * @return \Illuminate\Http\Response
     */
    public function destroy(sdgspendidikan $sdgspendidikan)
    {
        //
    }
}
