<?php

namespace App\Http\Controllers;

use App\Exports\data_individu;
use Carbon\Carbon;
use App\Exports\Exportdatapenduduk;
use App\Models\agama;
use App\Models\pendidikan;
use App\Models\pekerjaan;
use App\Models\status;
use App\Models\goldar;
use App\Models\datapenduduk;
use App\Models\dataindividu;
use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\StoredatapendudukRequest;
use App\Http\Requests\UpdatedatapendudukRequest;
use App\Imports\Importdatapenduduk;
use App\Models\detailkk;
use App\Models\kk;
use PhpOffice\PhpSpreadsheet\IOFactory;



class DatapendudukController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return view('datapenduduk.data');
    }
    public function index_admin(Request $request)
    {
        return view('datapenduduk.admindata');
    }


    public function dasawisma(Request $request)
    {
        return view('datapenduduk.dasawismaindex');
    }

    public function jsonadmin(Request $request)
    {
        $allowedDatakValues = ['tetap', 'tidaktetap'];

        $query = Datapenduduk::with(['kk', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status', 'detailkk.kk', 'updatedByUser'])
            ->whereIn('Datak', $allowedDatakValues);

        return DataTables::of($query)
            ->addColumn('nokk', function ($row) {
                return optional($row->detailkk->kk)->nokk;
            })
            // ⬇️ Izinkan pencarian global di kolom NO KK (relasi)
            ->filterColumn('nokk', function ($q, $keyword) {
                $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                    $qq->where('nokk', 'like', "%{$keyword}%");
                });
            })
            // (opsional) izinkan sorting kolom NO KK
            ->orderColumn('nokk', function ($q, $order) {
                $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
                    ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
                    ->orderBy('kks.nokk', $order)
                    ->select('datapenduduks.*'); // hindari duplikasi kolom
            })

            ->addColumn('updated_by', function ($datapenduduk) {
                return optional($datapenduduk->updatedByUser)->name; // Menampilkan nama user
            })
            ->addColumn('action', function ($datapenduduk) {
                $editUrl = route('datapenduduk.show', ['nik' => $datapenduduk->nik]);
                $deleteForm = '<form onsubmit="return deleteData(\'' . $datapenduduk->nama . '\')"
                                action="' . url('datapenduduk') . '/' . $datapenduduk->nik . '" style="display: inline"
                                method="POST">
                                ' . csrf_field() . '
                                ' . method_field('DELETE') . '
                            </form>';
                $actionsHtml = '<a href="' . $editUrl . '" class="btn mb-1 btn-info btn-sm" title="Edit data">
                                <i class="fas fa-edit"></i>
                            </a>
                            ' . $deleteForm;

                return $actionsHtml;
            })
            ->rawColumns(['action'])
            ->toJson();
    }



    public function json(Request $request)
    {
        $allowedDatakValues = ['tetap', 'tidaktetap'];

        // Cek apakah ada pencarian global dari DataTables atau filter nokk khusus
        $hasGlobalSearch = filled(data_get($request->all(), 'search.value')); // DataTables global search
        $hasNokkFilter   = $request->filled('nokk');

        if (! $hasGlobalSearch && ! $hasNokkFilter) {
            // Tidak ada search & tidak ada filter spesifik → sembunyikan data
            $query = Datapenduduk::query()->whereRaw('1=0');
        } else {
            // Ada search atau ada filter nokk → tampilkan data dengan relasi
            $query = Datapenduduk::with([
                'kk',
                'agama',
                'pendidikan',
                'pekerjaan',
                'goldar',
                'status',
                'detailkk.kk',
                'updatedByUser'
            ])->whereIn('Datak', $allowedDatakValues);

            // Filter opsional by NoKK dari parameter khusus
            if ($hasNokkFilter) {
                $nokk = $request->input('nokk');
                $query->whereHas('detailkk.kk', function ($qq) use ($nokk) {
                    $qq->where('nokk', 'like', "%{$nokk}%");
                });
            }
            // Catatan: global search akan ditangani otomatis oleh Yajra pada kolom sederhana.
            // Untuk kolom relasi (nokk) kita sediakan filterColumn di bawah.
        }

        return DataTables::of($query)
            ->addColumn('nokk', function ($row) {
                return optional(optional($row->detailkk)->kk)->nokk;
            })
            // Global search untuk kolom relasi NOKK
            ->filterColumn('nokk', function ($q, $keyword) {
                $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                    $qq->where('nokk', 'like', "%{$keyword}%");
                });
            })
            // Sorting NOKK (opsional)
            ->orderColumn('nokk', function ($q, $order) {
                $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
                    ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
                    ->orderBy('kks.nokk', $order)
                    ->select('datapenduduks.*');
            })
            ->addColumn('updated_by', function ($row) {
                return optional($row->updatedByUser)->name;
            })
            ->addColumn('action', function ($row) {
                $editUrl = route('datapenduduk.show', ['nik' => $row->nik]);
                $deleteForm = '<form onsubmit="return deleteData(\'' . e($row->nama) . '\')"
                               action="' . url('datapenduduk/' . $row->nik) . '"
                               method="POST" style="display:inline">' .
                    csrf_field() . method_field('DELETE') .
                    '</form>';
                return '<a href="' . $editUrl . '" class="btn mb-1 btn-info btn-sm" title="Edit data">
                        <i class="fas fa-edit"></i>
                    </a>' . $deleteForm;
            })
            ->rawColumns(['action'])
            ->toJson();
    }






    public function add()
    {
        $agama      = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan  = Pekerjaan::all();
        $goldar     = Goldar::all();
        $status     = Status::all();

        $statusKawinId = Status::whereRaw('LOWER(nama) LIKE ?', ['%kawin%'])->value('id') ?? 0;

        return view('datapenduduk.tambahpenduduk', compact(
            'agama',
            'pendidikan',
            'pekerjaan',
            'goldar',
            'status',
            'statusKawinId'
        ));
    }


    public function lookupByNik(string $nik)
    {
        $nik = preg_replace('/\D/', '', $nik);

        if (strlen($nik) !== 16) {
            return response()->json([
                'success' => false,
                'message' => 'NIK harus terdiri atas 16 digit.',
            ], 422);
        }

        // Ambil data penduduk beserta seluruh relasi yang dibutuhkan
        $penduduk = Datapenduduk::with([
            'agama',
            'pendidikan', // INI YANG SEBELUMNYA BELUM ADA
            'pekerjaan',
            'status',
            'detailkk.kk',
        ])
            ->where('nik', $nik)
            ->first();

        if (!$penduduk) {
            return response()->json([
                'success' => false,
                'message' => 'NIK tidak ditemukan.',
            ], 404);
        }

        // Normalisasi jenis kelamin
        $jenisKelaminRaw = strtolower(
            trim((string) ($penduduk->jenis_kelamin ?? ''))
        );

        $jenisKelamin = match ($jenisKelaminRaw) {
            '1', 'l', 'lk', 'laki-laki', 'laki laki', 'lakilaki'
            => 'Laki-Laki',

            '2', 'p', 'pr', 'perempuan'
            => 'Perempuan',

            default => '',
        };

        // Format tanggal lahir
        $tanggalLahir = '';

        if (!empty($penduduk->tanggal_lahir)) {
            try {
                $tanggalLahir = Carbon::parse(
                    $penduduk->tanggal_lahir
                )->format('Y-m-d');
            } catch (\Throwable $e) {
                $tanggalLahir = '';
            }
        }

        // Ambil pendidikan dari relasi
        $pendidikan = optional($penduduk->pendidikan)->nama
            ?? optional($penduduk->pendidikan)->pendidikan
            ?? optional($penduduk->pendidikan)->nama_pendidikan
            ?? '';

        // Ambil pekerjaan dari relasi
        $pekerjaan = optional($penduduk->pekerjaan)->nama
            ?? optional($penduduk->pekerjaan)->pekerjaan
            ?? optional($penduduk->pekerjaan)->nama_pekerjaan
            ?? '';

        // Ambil agama dari relasi
        $agama = optional($penduduk->agama)->nama
            ?? optional($penduduk->agama)->agama
            ?? optional($penduduk->agama)->nama_agama
            ?? '';

        // Ambil status perkawinan
        $statusPerkawinan = optional($penduduk->status)->nama
            ?? optional($penduduk->status)->status
            ?? optional($penduduk->status)->nama_status
            ?? '';

        // Nomor kartu keluarga
        $nokk = optional(
            optional($penduduk->detailkk)->kk
        )->nokk ?? '';

        // Kirim seluruh data ke JavaScript
        return response()->json([
            'success' => true,
            'message' => 'Data penduduk ditemukan.',

            'data' => [
                'nik' => $penduduk->nik ?? '',
                'nama' => $penduduk->nama ?? '',
                'tempat_lahir' => $penduduk->tempat_lahir ?? '',
                'tanggal_lahir' => $tanggalLahir,
                'jenis_kelamin' => $jenisKelamin,

                'pendidikan' => $pendidikan,
                'pekerjaan' => $pekerjaan,
                'agama' => $agama,

                'alamat' => $penduduk->alamat ?? '',
                'rt' => $penduduk->RT ?? $penduduk->rt ?? '',
                'rw' => $penduduk->RW ?? $penduduk->rw ?? '',
                'nokk' => $nokk,

                'status_perkawinan' => $statusPerkawinan,
            ],
        ]);
    }


    public function addadmin()
    {
        $agama      = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan  = Pekerjaan::all();
        $goldar     = Goldar::all();
        $status     = Status::all();

        $statusKawinId = Status::whereRaw('LOWER(nama) LIKE ?', ['%kawin%'])->value('id') ?? 0;

        return view('datapenduduk.tambahpendudukuser', compact(
            'agama',
            'pendidikan',
            'pekerjaan',
            'goldar',
            'status',
            'statusKawinId'
        ));
    }


    public function export_excel()
    {
        $filename = 'datapenduduk_'
            . now()->format('Ymd_His')
            . '.xlsx';

        return Excel::download(
            new Exportdatapenduduk(),
            $filename
        );
    }

    public function import_excel(Request $request)
    {
        $request->validate(
            [
                'file' => [
                    'required',
                    'file',
                    'mimes:xlsx',
                    'max:20480',
                ],
            ],
            [
                'file.required' =>
                'File XLSX wajib dipilih.',

                'file.file' =>
                'File import tidak valid.',

                'file.mimes' =>
                'File import harus berformat XLSX.',

                'file.max' =>
                'Ukuran file maksimal 20 MB.',
            ]
        );

        $file = $request->file('file');

        if (
            !$file ||
            !$file->isValid()
        ) {
            return redirect()
                ->back()
                ->withErrors([
                    'file' =>
                    'File gagal diunggah. Silakan pilih ulang file XLSX.',
                ]);
        }

        $import = new Importdatapenduduk();

        try {
            Excel::import(
                $import,
                $file
            );
        } catch (Throwable $e) {
            Log::error('Import data penduduk gagal', [
                'exception' => get_class($e),
                'message' => $e->getMessage(),
                'exception_file' => $e->getFile(),
                'exception_line' => $e->getLine(),

                'uploaded_name' =>
                $file->getClientOriginalName(),

                'uploaded_size' =>
                $file->getSize(),

                'uploaded_mime' =>
                $file->getMimeType(),

                'user_id' =>
                auth()->id(),

                'trace' =>
                $e->getTraceAsString(),
            ]);

            $message = config('app.debug')
                ? 'Import gagal: ' . $e->getMessage()
                : (
                    'Import gagal diproses. Detail kesalahan telah ' .
                    'disimpan pada log aplikasi.'
                );

            return redirect()
                ->back()
                ->with('error', $message);
        }

        $summary = $import->getSummary();

        $message =
            'Import selesai: ' .
            $summary['inserted'] .
            ' data baru berhasil diimpor, ' .
            $summary['skipped_existing'] .
            ' NIK sudah tersedia, ' .
            $summary['skipped_duplicate_file'] .
            ' NIK ganda dalam file, dan ' .
            $summary['invalid'] .
            ' baris tidak valid.';

        $routeName = (
            auth()->check() &&
            auth()->user()->role === 'admin'
        )
            ? 'datapenduduk.index_admin'
            : 'datapenduduk.index';

        /*
     * Tampilkan pesan merah apabila tidak ada satu pun data
     * berhasil masuk dan terdapat baris tidak valid.
     */
        $flashKey = (
            $summary['inserted'] === 0 &&
            $summary['invalid'] > 0
        )
            ? 'error'
            : 'msg';

        return redirect()
            ->route($routeName)
            ->with($flashKey, $message)
            ->with(
                'import_warnings',
                $summary['warnings']
            )
            ->with(
                'import_warning_overflow',
                $summary['warning_overflow']
            );
    }







    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoredatapendudukRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoredatapendudukRequest $request)
    {
        $validate = $request->validated();

        $datapenduduk = new DataPenduduk();
        $datapenduduk->nik = $request->valNIK;
        $datapenduduk->gelarawal = $request->valGelara ?? '';
        $datapenduduk->nama = $request->valNama;
        $datapenduduk->gelarakhir = $request->valGelart ?? '';
        $datapenduduk->jenis_kelamin = $request->valJeniskelamin;
        $datapenduduk->tempat_lahir = $request->valTempatlahir;
        $datapenduduk->tanggal_lahir = $request->valTanggallahir;
        $datapenduduk->agama_id = $request->valAgama;
        $datapenduduk->pendidikan_id = $request->valPendidikan;
        $datapenduduk->pekerjaan_id = $request->valPekerjaan;
        $datapenduduk->goldar_id = $request->valGoldar;
        $datapenduduk->status_id = $request->valStatus;
        $datapenduduk->tanggal_perkawinan = !empty($request->valTahunperkawinan)
            ? $request->valTahunperkawinan . '-01-01'  // simpan sebagai tanggal 1 Januari tahun tersebut
            : null;
        $datapenduduk->hubungan = $request->valHubungan;
        $datapenduduk->ayah = $request->valAyah;
        $datapenduduk->ibu = $request->valIbu;
        $datapenduduk->alamat = $request->valAlamat;
        $datapenduduk->rt = $request->valRT;
        $datapenduduk->rw = $request->valRW;
        $datapenduduk->datak = $request->valDatak;
        $datapenduduk->save();

        $kartuk = new kk();
        $kartuk->nokk = $request->valNokk;
        $kartuk->save();

        $detailk = new detailkk();
        $detailk->idpenduduk = $datapenduduk->id;
        $detailk->idkk = $kartuk->id;
        $detailk->save();


        if (auth()->check() && auth()->user()->role === 'admin') {
            return redirect()
                ->route('datapenduduk.index_admin')
                ->with('msg', 'Penduduk Berhasil ditambahkan (Admin)');
        }

        // Default untuk user biasa
        return redirect()
            ->route('datapenduduk.index')
            ->with('msg', 'Penduduk Berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\datapenduduk  $datapenduduk
     * @return \Illuminate\Http\Response
     */
    public function show(datapenduduk $datapenduduk, $nik)
    {
        $datapenduduk = datapenduduk::where('nik', $nik)->with(['detailkk.kk'])->firstOrFail();
        $agama      = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan  = Pekerjaan::all();
        $goldar     = Goldar::all();
        $status     = Status::all();

        // Cari ID status "Kawin" (fallback ke '1' jika tidak ditemukan)
        $statusKawinId = Status::whereRaw('LOWER(nama) = ?', ['kawin'])->value('id') ?? '1';

        // Format tanggal untuk <input type="date">
        $tglLahir = $datapenduduk->tanggal_lahir
            ? \Carbon\Carbon::parse($datapenduduk->tanggal_lahir)->format('Y-m-d')
            : '';
        $tahunPerkawinan = '';
        if ($datapenduduk->tanggal_perkawinan) {
            $tahunPerkawinan = Carbon::parse($datapenduduk->tanggal_perkawinan)->format('Y');
        }

        return view('datapenduduk.formedit', compact(
            'datapenduduk',
            'agama',
            'pendidikan',
            'pekerjaan',
            'goldar',
            'status',
            'statusKawinId'
        ))->with([
            'valKK'                 => optional(optional($datapenduduk->detailkk)->kk)->nokk,
            'valNIK'                => $nik,
            'valGelara'             => $datapenduduk->gelarawal,
            'valNama'               => $datapenduduk->nama,
            'valGelart'             => $datapenduduk->gelarakhir,
            'valJeniskelamin'       => (string)$datapenduduk->jenis_kelamin, // pastikan string
            'valTempatlahir'        => $datapenduduk->tempat_lahir,
            'valTanggallahir'       => $tglLahir,
            'valAgama'              => $datapenduduk->agama_id,
            'valPendidikan'         => $datapenduduk->pendidikan_id,
            'valPekerjaan'          => $datapenduduk->pekerjaan_id,
            'valGoldar'             => $datapenduduk->goldar_id,
            'valStatus'             => $datapenduduk->status_id,
            'valTahunperkawinan'    => $tahunPerkawinan,
            'valHubungan'           => $datapenduduk->hubungan,
            'valAyah'               => $datapenduduk->ayah,
            'valIbu'                => $datapenduduk->ibu,
            'valAlamat'             => $datapenduduk->alamat,
            'valRT'                 => $datapenduduk->rt,
            'valRW'                 => $datapenduduk->rw,
            'valDatak'              => $datapenduduk->datak,
        ]);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\datapenduduk  $datapenduduk
     * @return \Illuminate\Http\Response
     */
    public function edit(datapenduduk $datapenduduk) {}

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatedatapendudukRequest  $request
     * @param  \App\Models\datapenduduk  $datapenduduk
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatedatapendudukRequest $request, $nik)
    {
        // Retrieve the existing data for the specified NIK
        $datapenduduk = datapenduduk::where('nik', $nik)->first();

        if (!$datapenduduk) {
            return redirect()->back()->with('error', 'Data not found!');
        }

        // Update the penduduk fields
        $datapenduduk->gelarawal = $request->valGelara ?? '';
        $datapenduduk->nama = $request->valNama;
        $datapenduduk->gelarakhir = $request->valGelart ?? '';
        $datapenduduk->jenis_kelamin = $request->valJeniskelamin;
        $datapenduduk->tempat_lahir = $request->valTempatlahir;
        $datapenduduk->tanggal_lahir = $request->valTanggallahir;
        $datapenduduk->agama_id = $request->valAgama;
        $datapenduduk->pendidikan_id = $request->valPendidikan;
        $datapenduduk->pekerjaan_id = $request->valPekerjaan;
        $datapenduduk->goldar_id = $request->valGoldar;
        $datapenduduk->status_id = $request->valStatus;
        $datapenduduk->tanggal_perkawinan = !empty($request->valTahunperkawinan)
            ? $request->valTahunperkawinan . '-01-01'
            : null;
        $datapenduduk->hubungan = $request->valHubungan;
        $datapenduduk->ayah = $request->valAyah;
        $datapenduduk->ibu = $request->valIbu;
        $datapenduduk->alamat = $request->valAlamat;
        $datapenduduk->rt = $request->valRT;
        $datapenduduk->rw = $request->valRW;
        $datapenduduk->datak = $request->valDatak;
        $datapenduduk->save();

        // Now update the related kk record
        $detailkk = $datapenduduk->detailkk; // Get the related detailkk
        if ($detailkk) {
            $kk = $detailkk->kk; // Get the related kk
            if ($kk) {
                $kk->nokk = $request->valNokk; // Update the nokk
                $kk->save();
            }
        }

        return redirect('datapenduduk/admin')->with('msg', 'Penduduk Berhasil diperbarui');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\datapenduduk  $datapenduduk
     * @return \Illuminate\Http\Response
     */
    public function destroy(datapenduduk $datapenduduk, $nik) {}
}
