<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Surat Keterangan Desa Miskin</title>

    <style>
        @page {
            margin: 1.15cm 1.8cm;
        }

        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 11.5pt;
            line-height: 1.35;
            color: #000;
            margin: 0;
            padding: 0;
        }

        /* KOP SURAT FIX */
        .kop-desa-container {
            width: 100%;
            margin-bottom: 14px;
        }

        .kop-desa-table {
            width: 100%;
            border-collapse: collapse;
        }

        .kop-desa-logo {
            width: 16%;
            text-align: center;
            vertical-align: middle;
        }

        .kop-desa-logo img {
            width: 105px;
            height: auto;
        }

        .kop-desa-text {
            width: 68%;
            text-align: center;
            vertical-align: middle;
            line-height: 1.15;
        }

        .kop-desa-1 {
            font-size: 15pt;
            font-weight: normal;
            text-transform: uppercase;
        }

        .kop-desa-2 {
            font-size: 15pt;
            font-weight: normal;
            text-transform: uppercase;
        }

        .kop-desa-3 {
            font-size: 17pt;
            font-weight: bold;
            text-transform: uppercase;
        }

        .kop-desa-alamat {
            font-size: 11pt;
            margin-top: 2px;
        }

        .kop-desa-kontak {
            font-size: 10pt;
        }

        .kop-desa-garis {
            border: none;
            border-top: 3px solid #000;
            border-bottom: 1px solid #000;
            height: 3px;
            margin: 6px 0 12px 0;
        }

        .judul {
            text-align: center;
            font-weight: bold;
            text-decoration: underline;
            font-size: 13.5pt;
            margin-top: 12px;
        }

        .nomor {
            text-align: center;
            margin-bottom: 18px;
        }

        .isi {
            text-align: justify;
        }

        table.data {
            width: 100%;
            border-collapse: collapse;
            margin: 8px 0 12px 25px;
        }

        table.data td {
            padding: 3px 5px;
            vertical-align: top;
        }

        table.data td:first-child {
            width: 170px;
        }

        table.data td:nth-child(2) {
            width: 10px;
        }

        .ttd {
            width: 100%;
            margin-top: 38px;
            border-collapse: collapse;
        }

        .ttd td {
            width: 50%;
            text-align: center;
            vertical-align: top;
        }

        .space-sign {
            height: 65px;
        }

        .ttd-img-wrapper {
            height: 55px;
            margin: 5px 0 3px 0;
        }

        .ttd-img {
            width: 165px;
        }

        .nama-kades {
            font-weight: bold;
            text-decoration: underline;
        }

        .qr-section {
            margin-top: 6px;
            text-align: center;
        }

        .qr-section img {
            width: 78px;
        }

        .qr-section small {
            font-size: 7.3pt;
            color: #555;
            display: block;
        }

        @media print {
            body {
                margin: 0;
                padding: 0;
            }

            .kop-desa-garis {
                margin: 6px 0 12px 0;
            }
        }
    </style>
</head>

<body>
@php
    $tanggalSurat = now('Asia/Jakarta') ->locale('id')->translatedFormat('d F Y');

    $tanggalLahir = !empty($data->tanggal_lahir)
        ? \Carbon\Carbon::parse($data->tanggal_lahir) ->locale('id')->translatedFormat('d F Y')
        : '...........................................';
@endphp

<!-- KOP SURAT -->
<div class="kop-desa-container">
    <table class="kop-desa-table">
        <tr>
            <td class="kop-desa-logo">
                <img src="{{ public_path('assets/images/blitar.jpg') }}" alt="Logo Kabupaten Blitar">
            </td>

            <td class="kop-desa-text">
                <div class="kop-desa-1">PEMERINTAH KABUPATEN BLITAR</div>
                <div class="kop-desa-2">KECAMATAN KESAMBEN</div>
                <div class="kop-desa-3">PEMERINTAH DESA Wates</div>
                <div class="kop-desa-alamat">Jl. Merdeka No.74, Wates, Kec. Wates, Kabupaten Blitar, Jawa Timur Telp. 082139324445</div>
                <div class="kop-desa-kontak">
                    email :watesberkelas@gmail.com / website : Wates-blitarkab.desa.id
                </div>
            </td>

              {{-- <td class="kop-desa-logo">
                <img src="{{ public_path('assets/images/Wates.png') }}" alt="Logo Desa Wates">
            </td> --}}
        </tr>
    </table>

    <hr class="kop-desa-garis">
</div>

<div class="judul">SURAT KETERANGAN DESA</div>

<div class="nomor">
    Nomor : {{ app(\App\Services\NomorSuratService::class)->display($data, 'desa_miskin') }}
</div>

<div class="isi">
    <p>Yang bertanda tangan dibawah ini:</p>

    <table class="data">
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td>MOH HAMID ALMAULUDI</td>
        </tr>
        <tr>
            <td>Jabatan</td>
            <td>:</td>
            <td>KEPALA DESA Wates, Kec. Wates, Kab. Blitar</td>
        </tr>
    </table>

    <p>Menerangkan dengan sebenarnya bahwa:</p>

    <table class="data">
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td>{{ $data->nama ?? '...........................................' }}</td>
        </tr>
        <tr>
            <td>Tempat / Tanggal Lahir</td>
            <td>:</td>
            <td>{{ $data->tempat_lahir ?? '....................' }}, {{ $tanggalLahir }}</td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td>{{ $data->jenis_kelamin ?? '...........................................' }}</td>
        </tr>
        <tr>
            <td>Kewarganegaraan</td>
            <td>:</td>
            <td>{{ $data->kewarganegaraan ?? '...........................................' }}</td>
        </tr>
        <tr>
            <td>Tempat Tinggal</td>
            <td>:</td>
            <td>{{ $data->alamat ?? '...........................................' }}</td>
        </tr>
    </table>

    <p>
        Orang tersebut diatas adalah benar-benar penduduk Desa Wates Kec. Wates Kab. Blitar.
    </p>

    <p>
        Orang tersebut diatas adalah benar-benar penduduk Desa Wates Kec. Wates Kab. Blitar,
        yang tergolong tidak mampu <strong>(MISKIN)</strong> yang belum masuk daftar usulan
        karena pada saat pendaftaran tertinggal.
    </p>

    <p>
        Surat keterangan ini kami berikan untuk
        <strong>{{ $data->keperluan ?? '...........................................' }}</strong>.
    </p>

    <p>
        Demikian surat keterangan ini dapat dipergunakan sebagaimana mestinya.
    </p>
</div>

<table class="ttd">
    <tr>
        <td></td>
        <td>Blitar, {{ $tanggalSurat }}</td>
    </tr>
    <tr>
        <td><strong>Bidan Desa</strong></td>
        <td><strong>KEPALA DESA Wates</strong></td>
    </tr>
    <tr>
        <td>
            <div class="space-sign"></div>
            <strong><u>...........................................</u></strong>
        </td>
        <td>
            {{-- <div class="ttd-img-wrapper">
                <img src="{{ public_path('assets/images/ttd.png') }}" class="ttd-img" alt="Tanda Tangan">
            </div> --}}
            <br><br>

            <div class="nama-kades">MOH HAMID ALMAULUDI</div>

              {{--
            <div class="qr-section">
                <img src="{{ public_path('assets/images/barcode.png') }}" alt="QR Code">
                <small>Scan untuk verifikasi surat resmi Desa Wates</small>
            </div> --}}
        </td>
    </tr>
</table>

</body>
</html>
