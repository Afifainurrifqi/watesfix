<?php

namespace App\Http\Controllers;

use App\Models\agama;
use App\Models\pendidikan;
use App\Models\pekerjaan;
use App\Models\status;
use App\Models\goldar;
use App\Models\datapenduduk;
use App\Models\penghasilan;
use App\Http\Requests\StorepenghasilanRequest;
use App\Http\Requests\UpdatepenghasilanRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\DataTables;

class PenghasilanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $totalPenduduk = datapenduduk::count();

        // Dapatkan jumlah data yang sudah terisi di tabel datapekerjaansdgs
        $dataTerisi = penghasilan::count();

        // Hitung presentase penyelesaian data
        $presentase = $totalPenduduk > 0 ? ($dataTerisi / $totalPenduduk) * 100 : 0;

        // Ambil data lainnya untuk ditampilkan di view
        $datapenghasilan = penghasilan::all();
        $penghasilanLabels = $datapenghasilan->pluck('penghasilan_utama')->toArray();
        $penghasilanCounts = $datapenghasilan->countBy('penghasilan_utama')->values()->toArray();
        return view('sdgs.individu.datapenghasilan', compact('datapenghasilan', 'penghasilanLabels', 'penghasilanCounts', 'presentase'));
    }

    public function admin_index(Request $request)
    {
        $totalPenduduk = datapenduduk::count();

        // Dapatkan jumlah data yang sudah terisi di tabel datapekerjaansdgs
        $dataTerisi = penghasilan::count();

        // Hitung presentase penyelesaian data
        $presentase = $totalPenduduk > 0 ? ($dataTerisi / $totalPenduduk) * 100 : 0;

        // Ambil data lainnya untuk ditampilkan di view
        $datapenghasilan = penghasilan::all();
        $penghasilanLabels = $datapenghasilan->pluck('penghasilan_utama')->toArray();
        $penghasilanCounts = $datapenghasilan->countBy('penghasilan_utama')->values()->toArray();

        return view('sdgs.individu.admin_data_sdgs_penghasilan', compact('datapenghasilan', 'penghasilanLabels', 'penghasilanCounts', 'presentase'));
    }

    public function jsonadmin(Request $request)
    {
        $allowedDatakValues = ['tetap', 'tidaktetap'];

        $query = Datapenduduk::with(['kk', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status', 'detailkk.kk'])
            ->whereIn('Datak', $allowedDatakValues);

        return DataTables::of($query)

            ->addColumn('nokk', function ($row) {
                return optional($row->detailkk->kk)->nokk;
            })
            // ⬇️ Izinkan pencarian global di kolom NO KK (relasi)
            ->filterColumn('nokk', function ($q, $keyword) {
                $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                    $qq->where('nokk', 'like', "%{$keyword}%");
                });
            })
            // (opsional) izinkan sorting kolom NO KK
            ->orderColumn('nokk', function ($q, $order) {
                $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
                    ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
                    ->orderBy('kks.nokk', $order)
                    ->select('datapenduduks.*'); // hindari duplikasi kolom
            })
            ->addColumn('action', function ($row) {
                return '<td>
                            <a href="' . route('penghasilan.show', ['show' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Lihat Data">
                                <i class="fas fa-book"></i>
                            </a>
                            <a href="' . route('penghasilan.edit', ['nik' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>';
            })

            ->addColumn('sumber', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $sumber = $datapenghasilan ? $datapenghasilan->sumber_penghasilan : '';

                return '' . $sumber . '';
            })
            ->addColumn('jumlah_aset', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $jumlah_aset = $datapenghasilan ? $datapenghasilan->jumlah_asset_darip : '';

                return '' . $jumlah_aset . '';
            })
            ->addColumn('satuan', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $satuan = $datapenghasilan ? $datapenghasilan->satuan : '';

                return '' . $satuan . '';
            })
            ->addColumn('penghasilan', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $penghasilan = $datapenghasilan ? number_format($datapenghasilan->penghasilan_setahun, 0, ',', '.') : '';

                return 'Rp' . $penghasilan;
            })
            ->addColumn('ekspor', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $ekspor = $datapenghasilan ? $datapenghasilan->expor : '';

                return '' . $ekspor . '';
            })
            ->rawColumns([
                'action',
                'sumber',
                'jumlah_aset',
                'satuan',
                'penghasilan',
                'ekspor',
            ])
            ->toJson();
    }


    public function json(Request $request)
    {
        $allowedDatakValues = ['tetap', 'tidaktetap'];

        // Cek apakah ada pencarian global dari DataTables atau filter nokk khusus
        $hasGlobalSearch = filled(data_get($request->all(), 'search.value')); // DataTables global search
        $hasNokkFilter   = $request->filled('nokk');

        if (! $hasGlobalSearch && ! $hasNokkFilter) {
            // Tidak ada search & tidak ada filter spesifik → sembunyikan data
            $query = Datapenduduk::query()->whereRaw('1=0');
        } else {
            // Ada search atau ada filter nokk → tampilkan data dengan relasi
            $query = Datapenduduk::with([
                'kk',
                'agama',
                'pendidikan',
                'pekerjaan',
                'goldar',
                'status',
                'detailkk.kk',
                'updatedByUser'
            ])->whereIn('Datak', $allowedDatakValues);

            // Filter opsional by NoKK dari parameter khusus
            if ($hasNokkFilter) {
                $nokk = $request->input('nokk');
                $query->whereHas('detailkk.kk', function ($qq) use ($nokk) {
                    $qq->where('nokk', 'like', "%{$nokk}%");
                });
            }
            // Catatan: global search akan ditangani otomatis oleh Yajra pada kolom sederhana.
            // Untuk kolom relasi (nokk) kita sediakan filterColumn di bawah.
        }

        return DataTables::of($query)

            ->addColumn('nokk', function ($row) {
                return optional($row->detailkk->kk)->nokk;
            })
            // ⬇️ Izinkan pencarian global di kolom NO KK (relasi)
            ->filterColumn('nokk', function ($q, $keyword) {
                $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                    $qq->where('nokk', 'like', "%{$keyword}%");
                });
            })
            // (opsional) izinkan sorting kolom NO KK
            ->orderColumn('nokk', function ($q, $order) {
                $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
                    ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
                    ->orderBy('kks.nokk', $order)
                    ->select('datapenduduks.*'); // hindari duplikasi kolom
            })
            ->addColumn('action', function ($row) {
                return '<td>
                            <a href="' . route('penghasilan.show', ['show' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Lihat Data">
                                <i class="fas fa-book"></i>
                            </a>
                            <a href="' . route('penghasilan.edit', ['nik' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>';
            })

            ->addColumn('sumber', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $sumber = $datapenghasilan ? $datapenghasilan->sumber_penghasilan : '';

                return '' . $sumber . '';
            })
            ->addColumn('jumlah_aset', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $jumlah_aset = $datapenghasilan ? $datapenghasilan->jumlah_asset_darip : '';

                return '' . $jumlah_aset . '';
            })
            ->addColumn('satuan', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $satuan = $datapenghasilan ? $datapenghasilan->satuan : '';

                return '' . $satuan . '';
            })
            ->addColumn('penghasilan', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $penghasilan = $datapenghasilan ? number_format($datapenghasilan->penghasilan_setahun, 0, ',', '.') : '';

                return 'Rp' . $penghasilan;
            })
            ->addColumn('ekspor', function ($row) {
                $datapenghasilan = penghasilan::where('nik', $row->nik)->first();
                $ekspor = $datapenghasilan ? $datapenghasilan->expor : '';

                return '' . $ekspor . '';
            })
            ->rawColumns([
                'action',
                'sumber',
                'jumlah_aset',
                'satuan',
                'penghasilan',
                'ekspor',
            ])
            ->toJson();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($nik)
    {
        $datap = datapenduduk::where('nik', $nik)->first();
        $dataph = penghasilan::where('nik', $nik)->first();
        $agama = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan = Pekerjaan::all();
        $goldar = Goldar::all();
        $status = Status::all();

        return view('sdgs.individu.editpenghasilan', compact('datap', 'dataph', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorepenghasilanRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorepenghasilanRequest $request)
    {
        $dataph = penghasilan::where('nik', $request->valNIK)->first();
        if ($dataph == NULL) {
            $dataph = new penghasilan();
        }
        $dataph->nik = $request->valNIK;
        $dataph->sumber_penghasilan = $request->valSumberpenghasilan;
        $dataph->jumlah_asset_darip = $request->valJumlahasset;
        $dataph->satuan = $request->valSatuan;
        $dataph->penghasilan_setahun = $request->valPenghasilanset;
        $dataph->expor = $request->valExport;
        $dataph->save();

        if (auth()->check() && auth()->user()->role === 'admin') {
            return redirect()
                ->route('datapenghasilan.admin_index')
                ->with('msg', 'Berhasil ditambahkan (Admin)');
        }

        // Default untuk user biasa
        return redirect()
            ->route('datapenghasilan.index')
            ->with('msg', 'Penduduk Berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\penghasilan  $penghasilan
     * @return \Illuminate\Http\Response
     */
    public function show(penghasilan $penghasilan, $nik)
    {
        $datap = datapenduduk::where('nik', $nik)->first();
        $dataph = penghasilan::where('nik', $nik)->first();
        $agama = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan = Pekerjaan::all();
        $goldar = Goldar::all();
        $status = Status::all();

        return view('sdgs.individu.viewpenghasilan', compact('datap', 'dataph', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\penghasilan  $penghasilan
     * @return \Illuminate\Http\Response
     */
    public function edit(penghasilan $penghasilan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatepenghasilanRequest  $request
     * @param  \App\Models\penghasilan  $penghasilan
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatepenghasilanRequest $request, penghasilan $penghasilan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\penghasilan  $penghasilan
     * @return \Illuminate\Http\Response
     */
    public function destroy(penghasilan $penghasilan)
    {
        //
    }
}
