<?php

namespace App\Http\Controllers;

use App\Models\agama;
use App\Models\pendidikan;
use App\Models\pekerjaan;
use App\Models\status;
use App\Models\goldar;
use App\Models\datapenduduk;
use Illuminate\Http\Request;
use App\Models\laink;
use App\Http\Requests\StorelainkRequest;
use App\Http\Requests\UpdatelainkRequest;
use Yajra\DataTables\DataTables;

class LainkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $totalPenduduk = datapenduduk::count();

        // Dapatkan jumlah data yang sudah terisi di tabel datapekerjaansdgs
        $dataTerisi = laink::count();

        // Hitung presentase penyelesaian data
        $presentase = $totalPenduduk > 0 ? ($dataTerisi / $totalPenduduk) * 100 : 0;

        return view('sdgs.KK.lain', compact('presentase'));
    }

    private function baseKkQuery(Request $request)
    {
        $allowedDatakValues = ['tetap', 'tidaktetap'];

        $q = Datapenduduk::query()
            ->whereIn('datapenduduks.Datak', $allowedDatakValues)
            ->where('datapenduduks.hubungan', 'Kepala Keluarga') // ✅ sesuaikan value kalau beda
            ->join('detailkks', 'detailkks.idpenduduk', '=', 'datapenduduks.id')
            ->join('kks', 'kks.id', '=', 'detailkks.idkk')
            ->select([
                'datapenduduks.*',
                'kks.nokk as nokk',
            ]);

        /**
         * ✅ OPTIONAL: kalau kamu punya filter noKK khusus (misal dari input)
         */
        if ($request->filled('nokk')) {
            $nokk = $request->input('nokk');
            $q->where('kks.nokk', 'like', "%{$nokk}%");
        }

        /**
         * ✅ OPTIONAL: kalau kamu mau filter by nik kepala juga
         */
        if ($request->filled('nik')) {
            $nik = $request->input('nik');
            $q->where('datapenduduks.nik', 'like', "%{$nik}%");
        }

        return $q;
    }

    public function admin_index(Request $request)
    {
        $totalKK = (clone $this->baseKkQuery(new Request()))
            ->distinct('nokk')
            ->count('nokk');

        $nikKepalaList = (clone $this->baseKkQuery(new Request()))
            ->pluck('datapenduduks.nik')
            ->unique()
            ->values();

        $terisiKK = laink::whereIn('nik_kepala', $nikKepalaList)->count();

        $presentase = $totalKK > 0 ? ($terisiKK / $totalKK) * 100 : 0;

        return view('sdgs.KK.admin_lain', compact('presentase'));
    }

    public function jsonadmin(Request $request)
    {
     $allowedDatakValues = ['tetap', 'tidaktetap'];

        $sub = Datapenduduk::query()
            ->whereIn('datapenduduks.Datak', $allowedDatakValues)
            ->join('detailkks', 'detailkks.idpenduduk', '=', 'datapenduduks.id')
            ->join('kks', 'kks.id', '=', 'detailkks.idkk')
            ->selectRaw('MIN(datapenduduks.id) as id')   // ambil 1 anggota per NO KK
            ->groupBy('kks.nokk');

        $query = Datapenduduk::query()
            ->joinSub($sub, 't', fn($join) => $join->on('datapenduduks.id', '=', 't.id'))
            ->join('detailkks', 'detailkks.idpenduduk', '=', 'datapenduduks.id')
            ->join('kks', 'kks.id', '=', 'detailkks.idkk')
            ->select('datapenduduks.*', 'kks.nokk as nokk');

        return DataTables::of($query)

            ->addColumn('nokk', function ($row) {
            return optional($row->detailkk->kk)->nokk;
        })
        // ⬇️ Izinkan pencarian global di kolom NO KK (relasi)
        ->filterColumn('nokk', function ($q, $keyword) {
            $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                $qq->where('nokk', 'like', "%{$keyword}%");
            });
        })
        // (opsional) izinkan sorting kolom NO KK
        ->orderColumn('nokk', function ($q, $order) {
            $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
              ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
              ->orderBy('kks.nokk', $order)
              ->select('datapenduduks.*'); // hindari duplikasi kolom
        })
            ->addColumn('action', function ($row) {
                return '<td>
                            <a href="' . route('laink.show', ['show' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Lihat Data">
                                <i class="fas fa-book"></i>
                            </a>
                            <a href="' . route('editlaink.edit', ['nik' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>';
            })

            ->addColumn('pengtransportsebelum', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $pengtransportsebelum = $datakesehatan ? $datakesehatan->pengtransportsebelum : '';

                return '' . $pengtransportsebelum . '';
            })

            ->addColumn('pengtransportsesudah', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $pengtransportsesudah = $datakesehatan ? $datakesehatan->pengtransportsesudah : '';

                return '' . $pengtransportsesudah . '';
            })

            ->addColumn('blt', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $blt = $datakesehatan ? $datakesehatan->blt : '';

                return '' . $blt . '';
            })

            ->addColumn('pkh', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $pkh = $datakesehatan ? $datakesehatan->pkh : '';

                return '' . $pkh . '';
            })

            ->addColumn('bst', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bst = $datakesehatan ? $datakesehatan->bst : '';

                return '' . $bst . '';
            })

            ->addColumn('bantuan_presiden', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_presiden = $datakesehatan ? $datakesehatan->bantuan_presiden : '';

                return '' . $bantuan_presiden . '';
            })

            ->addColumn('bantuan_umkm', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_umkm = $datakesehatan ? $datakesehatan->bantuan_umkm : '';

                return '' . $bantuan_umkm . '';
            })

            ->addColumn('bantuan_pekerja', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_pekerja = $datakesehatan ? $datakesehatan->bantuan_pekerja : '';

                return '' . $bantuan_pekerja . '';
            })

            ->addColumn('bantuan_anak', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_anak = $datakesehatan ? $datakesehatan->bantuan_anak : '';

                return '' . $bantuan_anak . '';
            })

            ->addColumn('lainnya', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $lainnya = $datakesehatan ? $datakesehatan->lainnya : '';

                return '' . $lainnya . '';
            })

            ->addColumn('rata_rata', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $rata_rata = $datakesehatan ? $datakesehatan->rata_rata : '';

                return '' . $rata_rata . '';
            })

            ->rawColumns([
                'action',
                'pengtransportsebelum',
                'pengtransportsesudah',
                'blt',
                'pkh',
                'bst',
                'bantuan_presiden',
                'bantuan_umkm',
                'bantuan_pekerja',
                'bantuan_anak',
                'lainnya',
                'rata_rata',
            ])

            ->toJson();
    }

    public function json(Request $request)
    {
         $allowedDatakValues = ['tetap', 'tidaktetap'];

        // Cek apakah ada pencarian global dari DataTables atau filter nokk khusus
        $hasGlobalSearch = filled(data_get($request->all(), 'search.value')); // DataTables global search
        $hasNokkFilter   = $request->filled('nokk');

        if (! $hasGlobalSearch && ! $hasNokkFilter) {
            // Tidak ada search & tidak ada filter spesifik → sembunyikan data
            $query = Datapenduduk::query()->whereRaw('1=0');
        } else {
            // Ada search atau ada filter nokk → tampilkan data dengan relasi
            $query = Datapenduduk::with([
                'kk',
                'agama',
                'pendidikan',
                'pekerjaan',
                'goldar',
                'status',
                'detailkk.kk',
                'updatedByUser'
            ])->whereIn('Datak', $allowedDatakValues);

            // Filter opsional by NoKK dari parameter khusus
            if ($hasNokkFilter) {
                $nokk = $request->input('nokk');
                $query->whereHas('detailkk.kk', function ($qq) use ($nokk) {
                    $qq->where('nokk', 'like', "%{$nokk}%");
                });
            }
            // Catatan: global search akan ditangani otomatis oleh Yajra pada kolom sederhana.
            // Untuk kolom relasi (nokk) kita sediakan filterColumn di bawah.
        }

        return DataTables::of($query)

            ->addColumn('nokk', function ($row) {
            return optional($row->detailkk->kk)->nokk;
        })
        // ⬇️ Izinkan pencarian global di kolom NO KK (relasi)
        ->filterColumn('nokk', function ($q, $keyword) {
            $q->whereHas('detailkk.kk', function ($qq) use ($keyword) {
                $qq->where('nokk', 'like', "%{$keyword}%");
            });
        })
        // (opsional) izinkan sorting kolom NO KK
        ->orderColumn('nokk', function ($q, $order) {
            $q->join('detailkks', 'detailkks.nik', '=', 'datapenduduks.nik')
              ->join('kks', 'kks.id', '=', 'detailkks.kk_id')
              ->orderBy('kks.nokk', $order)
              ->select('datapenduduks.*'); // hindari duplikasi kolom
        })
            ->addColumn('action', function ($row) {
                return '<td>
                            <a href="' . route('laink.show', ['show' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Lihat Data">
                                <i class="fas fa-book"></i>
                            </a>
                            <a href="' . route('editlaink.edit', ['nik' => $row->nik]) . '" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>';
            })

            ->addColumn('pengtransportsebelum', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $pengtransportsebelum = $datakesehatan ? $datakesehatan->pengtransportsebelum : '';

                return '' . $pengtransportsebelum . '';
            })

            ->addColumn('pengtransportsesudah', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $pengtransportsesudah = $datakesehatan ? $datakesehatan->pengtransportsesudah : '';

                return '' . $pengtransportsesudah . '';
            })

            ->addColumn('blt', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $blt = $datakesehatan ? $datakesehatan->blt : '';

                return '' . $blt . '';
            })

            ->addColumn('pkh', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $pkh = $datakesehatan ? $datakesehatan->pkh : '';

                return '' . $pkh . '';
            })

            ->addColumn('bst', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bst = $datakesehatan ? $datakesehatan->bst : '';

                return '' . $bst . '';
            })

            ->addColumn('bantuan_presiden', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_presiden = $datakesehatan ? $datakesehatan->bantuan_presiden : '';

                return '' . $bantuan_presiden . '';
            })

            ->addColumn('bantuan_umkm', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_umkm = $datakesehatan ? $datakesehatan->bantuan_umkm : '';

                return '' . $bantuan_umkm . '';
            })

            ->addColumn('bantuan_pekerja', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_pekerja = $datakesehatan ? $datakesehatan->bantuan_pekerja : '';

                return '' . $bantuan_pekerja . '';
            })

            ->addColumn('bantuan_anak', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $bantuan_anak = $datakesehatan ? $datakesehatan->bantuan_anak : '';

                return '' . $bantuan_anak . '';
            })

            ->addColumn('lainnya', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $lainnya = $datakesehatan ? $datakesehatan->lainnya : '';

                return '' . $lainnya . '';
            })

            ->addColumn('rata_rata', function ($row) {
                $datakesehatan = laink::where('nik', $row->nik)->first();
                $rata_rata = $datakesehatan ? $datakesehatan->rata_rata : '';

                return '' . $rata_rata . '';
            })

            ->rawColumns([
                'action',
                'pengtransportsebelum',
                'pengtransportsesudah',
                'blt',
                'pkh',
                'bst',
                'bantuan_presiden',
                'bantuan_umkm',
                'bantuan_pekerja',
                'bantuan_anak',
                'lainnya',
                'rata_rata',
            ])

            ->toJson();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($nik)
    {
        $datap = datapenduduk::where('nik', $nik)->first();
        $laink = laink::where('nik', $nik)->first();
        $agama = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan = Pekerjaan::all();
        $goldar = Goldar::all();
        $status = Status::all();

        return view('sdgs.KK.editlaink', compact('laink', 'datap', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorelainkRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorelainkRequest $request)
    {
        $laink = laink::where('nik', $request->valNIK)->first();
        if ($laink == NULL) {
            $laink = new laink();
        }
        $laink->nik = $request->valNIK;

        $laink->pengtransportsebelum = $request->valpengtransportsebelum;
        $laink->pengtransportsesudah = $request->valpengtransportsesudah;
        $laink->blt = $request->valblt;
        $laink->pkh = $request->valpkh;
        $laink->bst = $request->valbst;
        $laink->bantuan_presiden = $request->valbantuan_presiden;
        $laink->bantuan_umkm = $request->valbantuan_umkm;
        $laink->bantuan_pekerja = $request->valbantuan_pekerja;
        $laink->bantuan_anak = $request->valbantuan_anak;
        $laink->lainnya = $request->vallainnya;
        $laink->rata_rata = $request->valrata_rata;

        $laink->save();
         if (auth()->check() && auth()->user()->role === 'admin') {
            return redirect()
                ->route('laink.admin_index')
                ->with('msg', 'Berhasil ditambahkan (Admin)');
        }

        // Default untuk user biasa
        return redirect()
            ->route('laink.index')
            ->with('msg', 'Penduduk Berhasil ditambahkan');
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\laink  $laink
     * @return \Illuminate\Http\Response
     */
    public function show(laink $laink, $nik)
    {
        $datap = datapenduduk::where('nik', $nik)->first();
        $laink = laink::where('nik', $nik)->first();
        $agama = Agama::all();
        $pendidikan = Pendidikan::all();
        $pekerjaan = Pekerjaan::all();
        $goldar = Goldar::all();
        $status = Status::all();

        return view('sdgs.KK.showlaink', compact('laink', 'datap', 'agama', 'pendidikan', 'pekerjaan', 'goldar', 'status'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\laink  $laink
     * @return \Illuminate\Http\Response
     */
    public function edit(laink $laink)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatelainkRequest  $request
     * @param  \App\Models\laink  $laink
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatelainkRequest $request, laink $laink)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\laink  $laink
     * @return \Illuminate\Http\Response
     */
    public function destroy(laink $laink)
    {
        //
    }
}
